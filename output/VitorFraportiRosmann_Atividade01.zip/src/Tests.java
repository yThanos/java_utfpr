/**
 * @author vitor.rosmann on 13/03/2025
 */
public class Tests {
    public static void main(String[] args) {
        System.out.println();
    }
}
