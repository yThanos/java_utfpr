package dev.fraporti;

/**
 * @author vitor.rosmann on 17/03/2025
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}