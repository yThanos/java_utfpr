package dev.fraporti.atividade_7.interfaces;

/**
 * @author vitor.rosmann on 07/04/2025
 */
public interface Calcular {
    int calcular();
}
